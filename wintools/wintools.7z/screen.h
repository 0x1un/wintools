#pragma once
#include <wtypes.h>
#include <iostream>

struct Resolution {
	int height;
	int width;
};

class Screen {
public:
	Resolution get_resolution();
	void set_resolution(int width, int height);
};
