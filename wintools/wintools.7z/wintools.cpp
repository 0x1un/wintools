#include <iostream>
#include "Base.h"

using namespace std;


void pause() {
	system("pause");
	cout << "pause program terminated. Resuming...\n";
}

int main(int argc, char** argv) {
	Base base;
	base.change_ip_or_resolution();
}
