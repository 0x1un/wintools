#pragma once
class Base
{
public:
	void change_ip_or_resolution();
};

